<?php
require_once("config.php");
    //Definimos la funciones para trabajar en PHP 
    function test_input($cadena){
        htmlspecialchars($cadena);
		addslashes($cadena);
		return $cadena;   
    }
    
    //funciones para conexion y consulta a base de datos
    function conexion_bd(){
       $conecta = mysqli_connect(LOCALHOST, ROOT, CONTRASEÑA)or die('No se pudo conectar al servidor');
	   mysqli_select_db($conecta, NOMBRE_BASE_DATOS)or die('No se pudo conectar a la base de datos');
       return $conecta;
    }
    function consulta($sql, $conexion){
	   $resultado = mysqli_query($conexion, $sql)or die(mysqli_error($conexion));
	   return $resultado;
    }
    
    //funcion que envia un correo electronico
    function envio_correo($dir_email, $asunto, $mensaje, $cabecera){
       $headers = "MIME-Version: 1.0/r/n";
	   $headers.= "Content-type: text/html; charset=iso-8859-1/r/n";	
	   $headers.= $cabecera."/r/n";
       return mail($dir_email, $asunto, $mensaje, $cabecera);
    }
    
    //funcion que genera una imagen captcha aleatoria
    function captchapng()
    {
        $captchaTextSize = 7;
        do {
            $md5Hash = md5( microtime( ) * mktime( ) );
            preg_replace( '([1aeilou0])', "", $md5Hash );
        } while( strlen( $md5Hash ) < $captchaTextSize );
        $key = substr( $md5Hash, 0, $captchaTextSize );
        $_SESSION['key'] = md5( $key );
        $captchaImage = imagecreatefrompng( "img/captcha.png" );
        $textColor = imagecolorallocate( $captchaImage, 31, 118, 92 );
        $lineColor = imagecolorallocate( $captchaImage, 15, 103, 103 );
        $imageInfo = getimagesize( "img/captcha.png" );
        $linesToDraw = 10;
        for( $i = 0; $i < $linesToDraw; $i++ )  {
            $xStart = mt_rand( 0, $imageInfo[ 0 ] );
            $xEnd = mt_rand( 0, $imageInfo[ 0 ] );
            imageline( $captchaImage, $xStart, 0, $xEnd, $imageInfo[1], $lineColor );
        }
        imagettftext( $captchaImage, 20, 0, 35, 35, $textColor, "VeraBd.ttf", $key );
        header("Content-type: image/png" );
        header("Cache-Control: no-cache, must-revalidate");
        header("Expires: Fri, 19 Jan 1994 05:00:00 GMT");
        header("Pragma: no-cache");
        imagepng( $captchaImage );
    }
    
    //funcion que verifica el Captcha... 
    function verificar_captcha($captcha){
        if($captcha == $_SESSION['key']){
            return true;
        }
        else {
            return false;
        }
    }
?>