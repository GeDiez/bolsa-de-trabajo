<?php	
    define('NOMBRE_BASE_DATOS', 'bolsa_trabajo'); // Defina sus datos
    define('ROOT','root');
    define('CONTRASEÑA',''); //Cambie los *** por su contraseña (ej: micontraseña2016)
    define('LOCALHOST', 'localhost'); // si Mysql estas intalado en el mismo servidor no modifique
?>
