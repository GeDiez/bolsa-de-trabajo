create table egresado(
	id_egresado int not null auto_increment primary key,
	nombre varchar(40) not null,
	carrera varchar(40) not null,
	email varchar(30) not null,
	generacion varchar(10) not null,
	titulado bool not null,
	domicilio varchar(100) not null,
	telefono varchar (15) not null,
	trabajo varchar(50) not null,
	password int(4) not null
);

create table empresa(
	id_empresa int not null auto_increment primary key,
	r_social varchar(80) not null,
	rfc varchar(15) not null,
	giro varchar(50) not null,
	titular varchar(50) not null,
	puesto_t varchar(30) not null,
	email varchar(30) not null,
	telefono varchar(15) not null,
	domicilio varchar(100) not null,
	paginaweb varchar(40) not null,
    	logo varchar(25) not null,
	password int(4) not null
);

create table oferta(
	id_oferta int auto_increment primary key not null,
	id_empresa int not null,
	solicita varchar(50) not null,
	puesto varchar(50) not null,
	n_vacantes int not null,
	requisitos mediumtext not null,
	foreign key (id_empresa) references empresa(id_empresa) ON DELETE CASCADE
);

create table solicitud(
	id_solicitud int auto_increment primary key not null,
	id_oferta int not null,
	id_egresado int not null,
	foreign key (id_oferta) references oferta(id_oferta),
	foreign key (id_egresado) references egresado(id_egresado) ON DELETE CASCADE
);
