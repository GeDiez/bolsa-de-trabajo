<div class="col-sm-12" style="color: #fff">
    <div class="text-center"><h2 style="color:#464646">Muro de vacantes</h2></div>
    <div class="row"> 
        <form role="form" class="form-horizontal" method="GET" action="egresado.php" autocomplete="off">
            <input type="hidden" name="query" value="ofertas">
            <div class="form-group">
                <label class="form-label col-sm-1 col-sm-offset-2">Carrera </label>
                <div class="col-sm-5">
                    <select class="form-control" name="carrera">
                        <option>Todo</option>
                        <option>Doctorado en Planificación y Desarrollo Regional</option>
                        <option>Maestría en Administración</option>
                        <option>Maestría en Docencia</option>
                        <option>Maestría en Construcción</option>
                        <option>Maestría en Planificación y Desarrollo Regional</option>
                        <option>Licenciado(s) en Informatica</option>
                        <option>Licenciado(s) en Administración</option>
                        <option>Ingeniero(s) Civil(es)</option>
                        <option>Ingeniero(s) Electronico(s)</option>
                        <option>Ingeniero(s) Electrico(s)</option>
                        <option>Ingeniero(s) en Gestión Empresarial</option>
                        <option>Ingeniero(s) Industrial(es)</option>
                        <option>Ingeniero(s) Mecanico(s)</option>
                        <option>Ingeniero(s) en Sistemas Computacionales</option>
                        <option>Ingeniero(s) Quimico(s)</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label col-sm-1 col-sm-offset-2">Empresa </label>
                <div class="col-sm-5">
                    <select class="form-control" name="empresa">
                        <option>Todo</option>
                        <?php 
                        while ($lempresa = mysqli_fetch_array($empresas)) {
                            echo "<option>".$lempresa['r_social'] ."</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="form-group">   
              <div class="col-sm-1 col-sm-offset-5">                
                <input class="btn btn-warning" type="submit" value="Buscar">            
              </div>           
            </div>
        </form>
    </div>
    <hr>
    <div class="col-sm-12">
    <?php 
    if ($ofertas != null) {   
        $nuevaFila = 0;
        while($oferta = mysqli_fetch_array($ofertas)){
        $nuevaFila++;
        if ($nuevaFila == 2) {
            echo "<div class='row'>";
        }
    ?>
        <div class='col-sm-6'> 
            <div class='panel panel-green'>
            <div class='panel-heading'>
                <?php echo $oferta['r_social']; ?>
            </div>
            <div class='panel-body'> 
                <table class='table'>
                <tbody>
                    <tr>
                    <td colspan='2' align='center'>
                        <img width='50px' heigth='50px' src='datosApp/logotipos/<?php echo $oferta['logo']?>'>
                    </td>
                    </tr>
                    <tr>
                    <td>Solicita:</td>
                    <td> <?php echo $oferta['solicita']; ?> </td>
                    </tr>
                    <tr>
                    <td>Vacantes: </td>
                    <td> <?php echo $oferta['n_vacantes'] ?> </td>
                    </tr>
                    <tr>
                    <td colspan='2'>
                        Requisitos: <br>                        
                        <?php echo $oferta['requisitos'] ?>
                        <br>
                        <a class="btn btn-success btn-sm" href="egresado.php?query=solicitar&id_oferta=<?php echo $oferta['id_oferta']?>">
                            Enviar Solicitud
                        </a>                   
                    </td>
                    </tr>
                </tbody>
                </table> 
            </div>
            </div>
        </div>
            
    <?php
         if ($nuevaFila == 2) {
                echo "</div>";
                $nuevaFila = 0;
            }
        }
        mysqli_free_result($ofertas);
        }
    else {
        echo "entro else";
        echo $_SESSION['msj'];
        $_SESSION['msj'] = "";
    }
    ?>
    </div>
    <hr>
</div>