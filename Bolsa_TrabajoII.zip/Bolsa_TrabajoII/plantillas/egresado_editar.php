<div class="col-sm-8 col-sm-offset-2">
    <form action="egresado.php?query=perfil-editar" method="POST">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>Editar datos del Egresado</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Nombre:</td>
                <td ><input name="nombre" type="text" value="<?php echo $_SESSION['nombre']; ?>"></td>
              </tr>
              <tr>
                <td>Carrera:</td>
                <td >
                    <select class="form-control" name="carrera">
                      <option <?php if($_POST['carrera'] == "Postgrados") { echo "selected=''"; } ?>>Postgrados</option>
                      <option <?php if($_POST['carrera'] == "Maestría en Administración") { echo "selected=''"; } ?>>Maestría en Administración</option>
                      <option <?php if($_POST['carrera'] == "Maestría en Docencia") { echo "selected=''"; } ?>>Maestría en Docencia</option>
                      <option <?php if($_POST['carrera'] == "Maestría en Construcción") { echo "selected=''"; } ?>>Maestría en Construcción</option>
                      <option <?php if($_POST['carrera'] == "Doctorado en Planificación del Desarrollo Regional") { echo "selected=''"; } ?>>Doctorado en Planificación del Desarrollo Regional</option>
                      <option <?php if($_POST['carrera'] == "Licenciatura en Administración") { echo "selected=''"; } ?>>Licenciatura en Administración</option>
                      <option <?php if($_POST['carrera'] == "Ingeniería Civil") { echo "selected=''"; } ?>>Ingeniería Civil</option>
                      <option <?php if($_POST['carrera'] == "Ingeniería Electornica") { echo "selected=''"; } ?>>Ingeniería Electronica</option>
                      <option <?php if($_POST['carrera'] == "Ingeniería Electrica") { echo "selected=''"; } ?>>Ingeniería Electrica</option>
                      <option <?php if($_POST['carrera'] == "Ingeniería en Gestion Empresarial") { echo "selected=''"; } ?>>Ingeniería en Gestion Empresarial</option>
                      <option <?php if($_POST['carrera'] == "Ingeniería Industrial") { echo "selected=''"; } ?>>Ingeniería Industrial</option>
                      <option <?php if($_POST['carrera'] == "Ingeniería Mecanica") { echo "selected=''"; } ?>>Ingeniería Mecanica</option>
                      <option <?php if($_POST['carrera'] == "Ingeniería en Sistemas Computacionales") { echo "selected=''"; } ?>>Ingeniería en Sistemas Computacionales</option>
                      <option <?php if($_POST['carrera'] == "Ingeniería Quimica") { echo "selected=''"; } ?>>Ingeniería Quimica</option>                    
                    </select>
                </td>
              </tr>
              <tr>
                <td>¿Eres Titulado?</td>
                <td>
                  <div class="radio-inline">
                      <label><input type="radio" name="titulado" value="si" checked>Si</label>
                  </div>
                  <div class="radio-inline">
                      <label><input type="radio" name="titulado" value="no">No</label>
                  </div>
                </td>
              </tr>           
              <tr>
                <td>Generación</td>
                <td ><input name="generacion" type="text" value="<?php echo $_SESSION['generacion']; ?>"></td>
              </tr>
            </tbody>                       
        </table>
        <table class="table table-hover"> 
          <thead>
            <tr>
              <th>Contacto</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Domicilio</td>
              <td ><input name="domicilio" type="text" value="<?php echo $_SESSION['domicilio']; ?>"></td>
            </tr>                
            <tr>
              <td>Teléfono:</td>
              <td ><input name="telefono" type="text" value="<?php echo $_SESSION['telefono']; ?>"></td>
            </tr>
            <tr>
              <td>E-mail:</td>
              <td ><input name="email" type="email" value="<?php echo $_SESSION['email']; ?>"></td>
            </tr>
          </tbody>
        </table>
        <div class = "form-group ">
            <input class="btn btn-warning" type="submit" value="Actualizar">        
        </div>
    </form>
</div>
