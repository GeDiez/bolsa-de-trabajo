<div class="col-sm-8 col-sm-offset-2">
      <div class="text-center"><h2 style="color:#464646">Contacto</h2></div>
    <form class="form-horizontal" role="form" autocomplete="off" method="POST" action="<?php if($_SESSION["id_egresado"]){echo"egresado";}else{echo"empresa";}?>.php?query=contacto">
        <div class="form-group">
        <label class="control-label col-sm-2">Correo electrónico</label>
        <div class="col-sm-10">
          <input disabled type="email" class="form-control" id="email" placeholder="micorreo@ejemplo.com" value =" <?php echo $_SESSION['email'];?> " name="email" required="">
        </div>
        </div>
        <div class="form-group">
        <label class="control-label col-sm-2">Asunto</label>
        <div class="col-sm-10">          
          <input type="text" class="form-control" name="asunto" required="">
        </div>
        </div>
        <div class="form-group">   
        <label class="control-label col-sm-2">Mensaje</label>     
        <div class="col-sm-10">
            <textarea rows="7" cols="47" placeholder="Queremos saber que opinas..." name="mensaje" required=""></textarea>
        </div>
        </div>
        <div class="form-group">        
        <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-warning">Enviar</button>
        </div>
        </div>
    </form>
    </div>