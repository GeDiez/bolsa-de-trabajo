<div class="col-sm-8 col-sm-offset-2">
    <div class="panel-group">
        <div class="panel panel-naranja">
            <div class="panel-heading">Solicitud de Ingreso a la Plataforma</div>
            <div class="panel-body">
                <form role="form" class="form-horizontal" method="POST" action="index.php?query=reg_egresado" autocomplete="off">
                    <div class="form-group">
                        <label class="control-label col-sm-4">Nombre: </label>
                        <div class="col-sm-6">
                            <input value="<?php echo $_POST['nombre'];?>" class="form-control" type="text" name="nombre" required="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4">Carrera: </label>
                        <div class="col-sm-6">
                            <select class="form-control" name="carrera">
                                <option <?php if($_POST['carrera'] == "Postgrados") { echo "selected=''"; } ?>>Postgrados</option>
                                <option <?php if($_POST['carrera'] == "Maestría en Administracion") { echo "selected=''"; } ?>>Maestría en Administración</option>
                                <option <?php if($_POST['carrera'] == "Maestría en Docencia") { echo "selected=''"; } ?>>Maestría en Docencia</option>
                                <option <?php if($_POST['carrera'] == "Maestría en Construccion") { echo "selected=''"; } ?>>Maestría en Construcción</option>
                                <option <?php if($_POST['carrera'] == "Maestría en Planificacion del Desarrollo Regional") { echo "selected=''"; } ?>>Maestría en Planificación del Desarrollo Regional</option>
                                <option <?php if($_POST['carrera'] == "Doctorado en Planificacion del Desarrollo Regional") { echo "selected=''"; } ?>>Doctorado en Planificacion del Desarrollo Regional</option>
                                <option <?php if($_POST['carrera'] == "Licenciatura en Administracion") { echo "selected=''"; } ?>>Licenciatura en Administracion</option>
                                <option <?php if($_POST['carrera'] == "Ingeniería Civil") { echo "selected=''"; } ?>>Ingeniería Civil</option>
                                <option <?php if($_POST['carrera'] == "Ingeniería Electronica") { echo "selected=''"; } ?>>Ingeniería Electronica</option>
                                <option <?php if($_POST['carrera'] == "Ingeniería Electrica") { echo "selected=''"; } ?>>Ingeniería Electrica</option>
                                <option <?php if($_POST['carrera'] == "Ingeniería en Gestion Empresarial") { echo "selected=''"; } ?>>Ingeniería en Gestion Empresarial</option>
                                <option <?php if($_POST['carrera'] == "Ingeniería Industrial") { echo "selected=''"; } ?>>Ingeniería Industrial</option>
                                <option <?php if($_POST['carrera'] == "Ingeniería Mecanica") { echo "selected=''"; } ?>>Ingeniería Mecanica</option>
                                <option <?php if($_POST['carrera'] == "Ingeniería en Sistemas Computacionales") { echo "selected=''"; } ?>>Ingeniería en Sistemas Computacionales</option>
                                <option <?php if($_POST['carrera'] == "Ingeniería Quimica") { echo "selected=''"; } ?>>Ingeniería Quimica</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4">Generación: </label>
                        <div class="col-sm-6">
                            <input value="<?php echo $_POST['generacion'];?>" class="form-control" type="text" name="generacion" required="" placeholder="20??-20??">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4">¿Eres Titulado?: </label>
                        <div class="col-sm-6">
                            <div class="radio">
                                <label><input type="radio" name="titulado" value="si" checked>Si</label>
                            </div>
                            <div class="radio">
                                <label><input type="radio" name="titulado" value="no">No</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4">¿Laboras actualmente? </label>
                        <div class="col-sm-6">
                            <input value="<?php echo $_POST['trabajo'];?>" class="form-control" type="text" name="trabajo" required="" placeholder="Nombre de la Organizacion">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4">Domicilio Particular: </label>
                        <div class="col-sm-6">
                            <input value="<?php echo $_POST['domicilio'];?>" class="form-control" type="text" name="domicilio" required="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4">Teléfono (lada-###-##-##): </label>
                        <div class="col-sm-6">
                            <input value="<?php echo $_POST['telefono'];?>" class="form-control" type="text" name="telefono" required="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4">E-mail: </label>
                        <div class="col-sm-6">
                            <input value="<?php echo $_POST['email'];?>" class="form-control" type="email" name="email" required="">
                        </div>
                    </div>
                    <div class="checkbox">
                        <label><input type="checkbox" required=""> 
                            La información registrada puede ser vista por otras Subdirecciones o Departamentos de esta Institución. Al acceder otorgas los permisos para que tu información proporcionada sea útil para los fines de la página Institucional.
                        </label>
                    </div>
                    <div class="form-group">
                      <div class="col-sm-offset-5">
                        <input class="btn btn-warning" type="submit" value="Registrarme">
                      </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
