<div class="col-sm-12 ">
    <div class="text-center"><h2 style="color:#464646;"><strong>Mis solicitudes de vacante</strong></h2></div>
    <table class="table table-hover">
        <thead>
        <tr>
            <th># Ofertas</th>
            <th>Se solicita</th>
            <th>Vacantes</th>
            <th class="text-center">Eliminar</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $contador = 1;
        while($oferta = mysqli_fetch_array($lista_de_ofertas)){
            if (!$oferta){
                echo "No ha creado ninguna oferta";
            }
            else{
                ?>
                <tr>
                <td><?php echo $contador ?></td>
                <td><?php echo $oferta['solicita'] ?></td>
                <td><?php echo $oferta['n_vacantes'] ?></td>
                <td class="text-center">
                    <a class="editar" href="empresa.php?query=lofertas&id_oferta=<?php echo $oferta['id_oferta'];?>"><span class="glyphicon glyphicon-remove"></a>
                    </td>
                </tr>
                <?php
                $contador = $contador + 1;
            }
        }
        mysqli_free_result($lista_de_ofertas);
        ?>
        </tbody>
    </table>
    <br>
</div>