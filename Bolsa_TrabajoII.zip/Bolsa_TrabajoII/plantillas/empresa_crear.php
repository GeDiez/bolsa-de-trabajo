<div class="col-sm-8 col-sm-offset-2">
    <div class="panel panel-naranja">
        <div class="panel-heading">Solicitud de Ingreso a la Plataforma</div>
        <div class="panel-body">
            <form role="form" enctype="multipart/form-data" class="form-horizontal" method="POST" action="index.php?query=reg_empresa" autocomplete="off">
                <div class="form-group">
                    <label class="control-label col-sm-4">Razón Social: </label>
                    <div class="col-sm-6">
                        <input value="<?php echo $_SESSION['r_social'];?>" class="form-control" type="text" name="r_social" required="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4">Logotipo oficial (1MB max JPG/PNG): </label>
                    <div class="col-sm-6">
                        <input name="logo" type="file" required=""/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4">Giro: </label>
                    <div class="col-sm-6">
                        <input value="<?php echo $_SESSION['giro'];?>" class="form-control" type="text" name="giro" required="" placeholder="¿A que se dedica?">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4">RFC: </label>
                    <div class="col-sm-6">
                        <input value="<?php echo $_SESSION['rfc'];?>" class="form-control" type="text" name="rfc" required="" style="text-transform: uppercase" placeholder="XXXX######????">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4">Titular de la Organización (Representante del area de contratación):</label>
                    <br>
                    <div class="col-sm-6">
                        <input value="<?php echo $_SESSION['titular'];?>" class="form-control" type="text" name="titular" required="" placeholder="Lic./Ing. nombre completo">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4">Puesto del Titular: </label>
                    <div class="col-sm-6">
                    <input value="<?php echo $_SESSION['puesto_t'];?>" class="form-control" type="text" name="puesto_t" required="" placeholder="cargo que ocupa.">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4">Domicilio: </label>
                    <div class="col-sm-6">
                        <input value="<?php echo $_SESSION['domicilio'];?>" class="form-control" type="text" name="domicilio" required="" placeholder="Domicilio Fiscal">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4">Teléfono: </label>
                    <div class="col-sm-6">
                    <input value="<?php echo $_SESSION['telefono'];?>" class="form-control" type="text" name="telefono" required="">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4">E-mail: </label>
                    <div class="col-sm-6">
                        <input value="<?php echo $_SESSION['email'];?>" class="form-control" type="email" name="email" required="" placeholder="correoEmpresa@ejemplo.com.mx">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-4">Página Web: </label>
                    <div class="col-sm-6">
                        <input value="<?php echo $_SESSION['paginaweb'];?>" class="form-control" type="text" name="paginaweb" required="">
                    </div>
                </div>
                <div class="col-sm-10 col-sm-offset-1">
                    <div class="checkbox">
                        <label><input type="checkbox" required="">Acepta: La información registrada es confidencial y sera utilizada con fines oficiales</label>
                    </div>
                </div>
                <div class="form-group">
                  <div class="col-sm-offset-5">
                    <input class="btn btn-warning" type="submit" value="Registrarme">
                  </div>
                </div>               
                </div>
            </form>
        </div>
    </div>
</div>    
