<div class="col-sm-5 col-sm-offset-1">
    <div class="well well-1 text-justify">
        <strong> SUBDIRECCIÓN DE PLANEACIÓN Y VINCULACIÓN <br> DEPARTAMENTO DE GESTIÓN TECNOLÓGICA Y VINCULACIÓN</strong>       
    </div>
    <div class="well well-1 text-justify">
      <strong> MISIÓN: </strong>
        <p>
            Somos un instrumento de desarrollo de la comunidad, con el compromiso de formar profesionistas de excelencia, capaces de responder de manera eficiente y específica a las necesidades con calidad, productividad y con una visión nacional e internacional para el presente y el futuro.
        </p>
    </div>
    <div class="well well-1 text-justify">
      <strong> VISIÓN: </strong>
        <p>
            Ser la mejor institución de educación superior tecnológica en la región y del país reconocida y acreditada internacionalmente como una institución de calidad.
        </p>
    </div>    
</div>
<div class="col-sm-4 col-sm-offset-1">
    <div class="panel-group">
        <div class="panel panel-naranja">
            <div class="panel-heading">
                Acceso a Egresados
            </div>
            <div class="panel-body">
                <form role="form" autocomplete="off" action="index.php?query=sesion_egresado" method="post">
                    <div class="form-group">
                        <label class="col-sm-5 text-right">E-mail: </label>
                        <input id="email1" type="email" name="email" required="" placeholder="micorreo@ejemplo.com">
                    </div>
                    <div class="form-group">
                        <label class="col-sm-5 text-right">Clave de acceso: </label>
                        <input id="clave1" type="password" name="clave" required="">
                    </div>
                    <div class="col-sm-12 text-center">
                        <input class="btn btn-warning" value="acceder" type="submit">
                    </div>
                </form>
                <a href="index.php?query=reg_egresado">Registrarse</a> <br>
                <a href="index.php?query=reestablecer_clave&usr=1">Recuperar mi clave de acceso</a> 
            </div>
        </div>
        <div class="panel panel-naranja" >
            <div class="panel-heading">
                Acceso a Empresas
            </div>
            <div class="panel-body">
                <form class="form-horizontal" autocomplete="off" action="index.php?query=empresa_sesion" method="post">
                    <div class="form-group">
                        <label class="control-label col-sm-4">RFC : </label>
                        <div class="col-sm-8">                        
                            <input class="form-control" type="text" name="rfc" required="" placeholder="XXXXAAMMDDHHHH" style="text-transform: uppercase">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4">Clave de acceso: </label>
                        <div class="col-sm-8">
                            <input class="form-control" type="password" name="clave" required="">
                        </div>
                    </div>
                    <div class="col-sm-12 text-center">
                        <input id="envioeg" class="btn btn-warning" value="acceder" type="submit">
                    </div>
                </form>
                <a href="index.php?query=reg_empresa">Registrarse</a><br>
                <a href="index.php?query=reestablecer_clave&usr=2">Recuperar mi clave de acceso</a> 
            </div>
        </div>
    </div>
</div>
