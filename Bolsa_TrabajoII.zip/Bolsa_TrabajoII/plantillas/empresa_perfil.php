<div class="col-sm-10 ">
    <table class="table table-hover">
        <thead>
            <tr>
            <th>Datos del la Empresa</th>
            </tr>
        </thead>
        <tbody>
            <tr>
            <td>Nombre de la Empresa:</td>
            <td><?php echo $_SESSION['r_social']; ?></td>
            </tr>
            <tr>
            <td>RFC:</td>         
            <td><?php echo $_SESSION['rfc']; ?></td>
            </tr>
            <tr>
            <td>Giro de la Empresa</td>
            <td><?php echo $_SESSION['giro']; ?></td>
            </tr>            
        </tbody>
    </table>
    
    <table class="table table-hover">
      <thead>
        <tr>
          <th>Contacto</th>
        </tr>
      </thead>
      <tbody>
        <tr>
        <td>Nombre del Titular de la Empresa</td>
        <td><?php echo $_SESSION['titular']; ?></td>
        </tr>
        <tr>
        <td>Puesto del titular:</td>
        <td><?php echo $_SESSION['puesto_t']; ?></td>
        </tr>             
        <tr>
        <td>Domicilio:</td>
        <td><?php echo $_SESSION['domicilio']; ?></td>
        </tr> 
        <tr>      
        <td>Telefono de Contacto:</td>
        <td><?php echo $_SESSION['telefono']; ?></td>
        </tr>
        <tr>
        <td>E-mail:</td>
        <td><?php echo $_SESSION['email']; ?></td>
        </tr>
        <tr>
        <td>Pagina Web:</td>
        <td><?php echo $_SESSION['paginaweb']; ?></td>
        </tr>
      </tbody>
    </table>
</div>
