<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bolsa de Trabajo ITO</title>
  <meta charset="utf-8">
  <link rel="icon" type="image/png" href="img/ico.png" />
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- estilos -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/micss.css">

  <!-- javascript -->
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>

</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>            
      </button>
      <a class="navbar-brand" href="#"><img class="logoITO2" src="img/ima.png"></img></a>
    </div>
    <div class="subtitulo2">
      TECNOLÓGICO NACIONAL DE MÉXICO <br> 
      INSTITUTO TECNOLÓGICO DE OAXACA<br>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-education">           
            Egresado</a>
            <ul class="dropdown-menu">
                <li><a href="egresado.php?query=perfil">Perfil</a></li>
                <li><a href="egresado.php?query=perfil-editar">Editar Perfil</a></li>
            </ul>            
        </li>
        <li><a href="egresado.php?query=ofertas&carrera=Todo&empresa=Todo"><span class="glyphicon glyphicon-briefcase"> Ver ofertas</a></li>
        <li><a href="egresado.php?query=cv"><span class="glyphicon glyphicon-list-alt"> Currículum</a></li>
        <li><a href="egresado.php?query=contacto"><span class="glyphicon glyphicon-envelope"> Contacto</a></li>
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="col-sm-2 sidenav">
    <div class="well well-2">
      <p>
         BIENVENIDO <br><br>
         En sesión: <?php echo $_SESSION['nombre'] ?> 
      </p>
    </div>
    <div class="well well-2">
      MI CUENTA <br><br>
      <ul class="text-left list-unstyled">
        <li><a class="btn btn-warning" href="index.php?query=cerrar_sesion" style="width: 100%">   Cerrar la sesión  </a></li>
        <li><a class="btn btn-warning" href="egresado.php?query=eliminar" style="width: 100%">Eliminar mi cuenta </a></li>
      </ul>      
    </div>
  </div>
  <div class="col-sm-8 text-left sidenav well-1">
    <div class="well well-sm text-center">
      SUBDIRECCIÓN DE PLANEACIÓN Y VINCULACIÓN <br>
      DEPARTAMENTO DE GESTIÓN TECNOLÓGICA Y VINCULACIÓN 
    </div>
    <div class="row">
        <div class="col-sm-8 col-sm-offset-2">
        <?php 
            if (!($_SESSION['msj'] == "")) {
        ?>
            <div class="alert alert-danger">
                <strong>¡Aviso!</strong> <?php echo $_SESSION['msj'];?>
            </div>
        <?php
            }
                $_SESSION['msj'] = "";                        
        ?>
        </div>
    </div>   
    <div class="row">
        <?php 
            switch ($_GET['query']) {
                case 'ofertas':
                    require_once("plantillas/egresado_ofertas.php");                    
                    break;
                
                case 'cv':
                    require_once("plantillas/egresado_cv.php");                    
                    break;
                    
                case 'perfil-editar':
                    require_once("plantillas/egresado_editar.php");                    
                    break;
                    
                case 'contacto':
                    require_once("plantillas/contacto.php");                    
                    break;
                    
                case 'eliminar':
                    require_once("plantillas/egresado_eliminar.php");                    
                    break;
                
                default:
                    require_once("plantillas/egresado_perfil.php");
                    break;
            }
        ?>
    </div>
  </div>
</div>

<footer class="container-fluid text-center">
  <p class="text-center">
      <hr>
      TECNOLÓGICO NACIONAL DE MÉXICO. INSTITUTO TECNOLÓGICO DE OAXACA. SUBDIRECCIÓN DE PLANEACIÓN Y VINCULACIÓN 
      <br>vin_oaxaca@tecnm.mx.
  </p>
</footer>

</body>
</html>
