<div class="col-sm-5 col-sm-offset-4">
    <div class="panel-group">
        <div class="panel panel-naranja">
            <div class="panel-heading">
                Recuperar mi clave de acceso
            </div>
            <div class="panel-body">
                <p>Necesitamos que proporciones tu correo o RFC en caso de las empresas para reenviarte tu clave de acceso</p>
                <form role="form" autocomplete="off" action="index.php?query=reestablecer_clave&usuario=<?php echo $_GET['usr'];?>" method="post">
                    <div class="form-group">
                        <label class="col-sm-5 text-right">Usuario: </label>
                        <input type="text" name="usuario" required="" placeholder="correo o RFC">
                    </div>
                    <div class="col-sm-12 text-center">
                        <input class="btn btn-warning" value="Enviar mi contraseña" type="submit">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>