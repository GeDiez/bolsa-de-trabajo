
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bolsa de Trabajo ITO</title>
  <meta charset="utf-8">
  <link rel="icon" type="image/png" href="img/ico.png" />
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- estilos -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/micss.css">

  <!-- funciones javascript -->
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
    <header>
        <div class="row encabezado text-center">
                <div class="col-lg-1 col-lg-offset-2">
                    <img class="logoITO" src="img/ima.png">
                </div>
                <div class="col-lg-4">
                    <p class="texto">
                        <h3>Tecnológico Nacional de México </h3>
                        <h4>Instituto Tecnológico de Oaxaca </h4>
                    </p>
                </div>
                <div class="col-lg-3">
                    <img class="logoSEP" src="img/logoSep.png">
                </div>
            </div>
    </header>
    <div class="container-fluid" >      
        <div class="sidenav">
            <div class="row">
                <div class="col-sm-10 col-sm-offset-1">
                    <div class="well well-1 text-justify">
                        <p class="text-center subtitulo">
                            BOLSA DE TRABAJO ITO
                        </p>
      Portal Bolsa de Trabajo del Instituto Tecnológico de Oaxaca.<br>
			La Subdirección de Planeación y Vinculación a través del Departamento de Gestión Tecnológica y Vinculación en apoyo a los <i>Egresados</i> de esta Institucion genera un portal web en donde las empresas dan a conocer las vacantes que ofrecen, para las diferentes carreras que se imparten en este Instituto con la finalidad de ofrecer nuevas oportunidades, de empleo a nuestros <i>Egresados</i> en sus diferentes niveles.
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2">
                <?php 
                    if (!($_SESSION['msj'] == "")) {
                ?>
                <div class="alert alert-danger">
                    <strong>¡Aviso!</strong> <?php echo $_SESSION['msj'];?>
                </div>
                <?php
                    }
                        $_SESSION['msj'] = "";                        
                ?>
                </div>
            </div>            
            <div class="row">
                <?php 
                    switch($_GET['query']){
                        case 'reg_egresado':
                            require_once("plantillas/egresado_crear.php");
                            break;
                        case 'reg_empresa':
                            require_once("plantillas/empresa_crear.php");
                            break;
                        case 'reestablecer_clave':
                            require_once("plantillas/reestablecer_clave.php");
                            break;
                        default:
                            require_once("plantillas/acceso.php");
                            break;
                    }
                ?>
            </div>
        </div>
    </div>
    <footer>
        <p class="text-center">
            <br>
            TECNOLÓGICO NACIONAL DE MÉXICO. INSTITUTO TECNOLÓGICO DE OAXACA. SUBDIRECCIÓN DE PLANEACIÓN Y VINCULACIÓN 
            <br>vin_oaxaca@tecnm.mx.
        </p>
    </footer>
</body>
</html>
