<div class="col-sm-10 col-sm-offset-1">
    <div class="well">
        <label >IMPORTANTE</label>
        <p class="text-center">
            Estas a punto de Eliminar tu cuenta de usuario. <br>
            ¿Deseas Confirmar eliminar tu cuenta?<br>
            <a class = "btn btn-warning" href="empresa.php?query=eliminar&confirmar=si">
                ¡CONFIRMAR!
            </a>
        </p>
    </div>
</div>