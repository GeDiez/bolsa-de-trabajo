<div class="col-sm-10 ">
    <table class="table table-hover">
    <thead>
        <tr>
        <th>Datos del Egresado</th>
        </tr>
    </thead>
    <tbody>
        <tr>
        <td>Nombre:</td>
        <td><?php echo $_SESSION['nombre']; ?></td>
        </tr>
        <tr>
        <td>Carrera:</td>
        <td><?php echo $_SESSION['carrera']; ?></td>
        </tr>
        <tr>
        <td>Generacion</td>
        <td><?php echo $_SESSION['generacion']; ?></td>
        </tr>
        <td>¿Eres Titulado?</td>
        <td><?php echo $_SESSION['titulado']; ?></td>
        </tr>              
    </tbody>
    </table>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Contacto</th>
        </tr>
      </thead>
      <tbody>
        <tr>
        <td>Domicilio</td>
        <td><?php echo $_SESSION['domicilio']; ?></td>
        </tr>                       
        <tr>
        <td>Teléfono:</td>
        <td><?php echo $_SESSION['telefono']; ?></td>
        </tr>
        <tr>
        <td>E-mail:</td>
        <td><?php echo $_SESSION['email']; ?></td>
        </tr>
        <tr>
      </tbody>
    </table>
</div>