<div class="col-sm-12 ">
    <form action="empresa.php?query=perfil-editar" method="POST">
        <h3>Perfil</h3>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Datos del la Empresa</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Nombre de la Empresa:</td>
                    <td><input name="r_social" type="text" value="<?php echo $_SESSION['r_social']; ?>"></td>
                </tr>
                <tr>
                    <td>RFC:</td>         
                    <td><input name="rfc" type="text" value="<?php echo $_SESSION['rfc']; ?>"></td>
                </tr>
                <tr>
                    <td>Giro de la Empresa</td>
                    <td><input name="giro" type="text" value="<?php echo $_SESSION['giro']; ?>"></td>
                </tr>
                <tr>
                    <td>Nombre del Titular de la Empresa</td>
                    <td><input name="titular" type="text" value="<?php echo $_SESSION['titular']; ?>"></td>
                </tr>                
                <tr>
                    <td>Domicilio:</td>
                    <td><input name="domicilio" type="text" value="<?php echo $_SESSION['domicilio']; ?>"></td>
                </tr>
                <tr>
                    <td>E-mail:</td>
                    <td><input name="puesto_t" type="text" value="<?php echo $_SESSION['puesto_t']; ?>"></td>
                </tr>
                <tr>
                    <td>Telefono de Contacto:</td>
                    <td><input name="telefono" type="text" value="<?php echo $_SESSION['telefono']; ?>"></td>
                </tr>
                    <td>Pagina Web:</td>
                    <td><input name="paginaweb" type="text" value="<?php echo $_SESSION['paginaweb']; ?>"></td>
                </tr>
            </tbody>
        </table>
        <div class = "form-group">
            <input type="submit" value="Actualizar">        
        </div>
    </form>
</div>
