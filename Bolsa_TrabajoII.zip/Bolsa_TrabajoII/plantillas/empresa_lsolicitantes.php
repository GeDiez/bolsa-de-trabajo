<?php 
  if (count($egresado = mysqli_fetch_array($lista_solicitantes)) === 0) {
?>
  <div class="row">
    <div class="col-sm-10 col-sm-offset-1">        
        <div class="well">
            <label>No encontramos solicitudes</label>
            <p>
              Al aprecer nadie ha solicitado tus vacantes :(
            </p>                                      
        </div>        
    </div>
  </div>
<?php
  }
  else{
    while ($egresado = mysqli_fetch_array($lista_solicitantes)) {
?>

<div class="row">
    <div class="col-sm-10 col-sm-offset-1">        
        <div class="well">
            <label>Nombre Solicitante: <?php echo $egresado['nombre']?></label>
            <label class="col-sm-offset-4">
                <a href="empresa.php?query=lsolicitantes&id_solicitud=<?php echo $egresado['id_solicitud']?>" class="btn btn-sm btn-success">
                    <span class="glyphicon glyphicon-remove">
                        Rechazar
                </a>
            </label>
            <p>
                Contacto:<br>
                <p>Telefono: <?php echo $egresado['telefono']?></p>
                <p>Email: <?php echo $egresado['email']?></p>
                <p>Curriculum Vitae PDF: <a class= "btn btn-warning" target="blank" href="datosApp/CV/cv-<?php echo $egresado['id_egresado']?>.pdf">Visualizar</a></p>                        
            </p>                           
        </div>        
    </div>
</div>

<?php
    }
  }
?>