<?php 
    if (file_exists("datosApp/CV/cv-".$_SESSION['id_egresado'].".pdf")) {
?>
    <div class="col-sm-10 col-sm-offset-1">
        <h3>Mi Curriculum Vitae</h3>
        <label class="col-sm-12"> 
            Ya tienes regitrado un curriculum en el servidor, para visualizar tu archivo:
            <a class = "btn btn-warning" target="blank" href="datosApp/CV/cv-<?php echo $_SESSION['id_egresado'];?>.pdf">
                Ver mi Currículum Vítae
            </a>
        </label>
      </div>
    </div>
    <hr>
<?php } ?>    
    <div class="col-sm-8 col-sm-offset-2" style="color: #fff; border: 4px solid #fff;">
        <div class="text-center"><h2 style="color:#464646;"><strong>Currículum Vítae</strong></h2></div>
        <form role="form" enctype="multipart/form-data" class="form-horizontal" method="POST" action="egresado.php?query=guarda-cv" autocomplete="off">
            <div class="form-group">
                <label class="col-sm-12" > 
                    En ésta sección deberas súbir tu Currículum Vítae al servidor del ITO.
                    Realiza los siguientes pasos;
                    <ol>
                        <li>Diseña tu Currículum Vítae como mejor te parezca, es una forma de mostrar tu creatividad,  
                            hazlo de una forma presentable, ya que este será la forma en que las empresas  
                            te van a conocer, anexa toda tu información profesional.
                        </li>
                        <li>Guarda tu archivo en formato PDF no mayor a 5 MB. </li>
                        <li>Regresa a esta sección y da clic al botón examinar.</li>
                        <li>Busca tu archivo en tu directorio personal y selecciónalo.</li>
                        <li>Por ultimo da clic en Guardar, esto lo enviara al servidor.</li>
                    </ol>
                    Ya puedes solicitar a las empresas algún puesto, en la sección de 'ofertas'.
                </label>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-4" style="color: #464646">Subir</label>
                <div class="col-sm-8">
                    <input class="btn btn-warning" name="archivo" type="file" required="">
                </div>                                
            </div>
            <div class="form-group">   
                <div class="col-sm-4 col-sm-offset-4">                
                    <input class="btn btn-warning" type="submit" value="Guardar">
                </div>
            </div>
        </form>
    </div>