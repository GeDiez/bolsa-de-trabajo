<div class="col-sm-10 ">
    <div class="text-center"><h2 style="color:#464646;"><strong>Crear ofertas</strong></h2></div>
    <form role="form" autocomplete="off" class="form-horozintal" action="empresa.php?query=ofertar" method="POST">
        <div class="well">
            <p><strong>Nota:</strong> 
                llene un formato por tipo de solicitante, 
                si desea agregar otra oferta para otro 
                solicitante pulse en Guardar/nuevaVacante
            </p>
            <span style="color: #FF0000">* Campos Requeridos </span>
        </div>
        <div class="row form-group">
            <label class="control-label col-sm-4">Tipo de vacante:<span style="color: #FF0000">*</span> </label>
            <div class="col-sm-6">
                <select class="form-control" name="solicita">
                    <option>Doctorado en Planificacion y Desarrollo Regional</option>
                    <option>Maestria en Administracion</option>
                    <option>Maestria en Docencia</option>
                    <option>Maestria en Construccion</option>
                    <option>Maestria en Planificacion y Desarrollo Regional</option>
                    <option>Licenciado(s) en Informatica</option>
                    <option>Licenciado(s) en Administracion</option>
                    <option>Ingeniero(s) Civil(es)</option>
                    <option>Ingeniero(s) Electronico(s)</option>
                    <option>Ingeniero(s) Electrico(s)</option>
                    <option>Ingeniero(s) en Gestion Empresarial</option>
                    <option>Ingeniero(s) Industrial(es)</option>
                    <option>Ingeniero(s) Mecanico(s)</option>
                    <option>Ingeniero(s) en Sistemas Computacionales</option>
                    <option>Ingeniero(s) Quimico(s)</option>                  
                </select>
            </div>
        </div>
        <div class="row form-group">
            <label class="control-label col-sm-4">Numero de Vacantes<span style="color: #FF0000">*</span> </label>
            <div class="col-sm-2">
                <input class="form-control" type="number" min="0" name="n_vacantes" required="">
            </div>
        </div>
        <div class="row form-group">
            <label class="control-label col-sm-4">Puesto/Nombre de la vacante<span style="color: #FF0000">*</span> </label>
            <div class="col-sm-8">
                <input class="form-control" type="text" name="puesto" required="">
            </div>
        </div>
        <div class="row form-group">
            <label class="control-label col-sm-4">Requisitos<span style="color: #FF0000">*</span> </label>
            <div class="col-sm-8">
                <textarea class="form-control" name="requisitos" required="" rows="10"></textarea>
            </div>
        </div>
        <input type="submit" value="Guardar/Nva Vacante">
    </form>
</div>