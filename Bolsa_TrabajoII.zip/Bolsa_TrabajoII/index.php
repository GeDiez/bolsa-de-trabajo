<?php
    if (isset($_SESSION['id_empresa'])) {
    header("location: empresa.php");
    exit(0);
    }
    if (isset($_SESSION['id_egresado'])) {
    header("location: egresado.php");
    exit(0);
    }
    session_start();
    require_once("controlador/despachador.php");
    require_once("plantillas/layout.php");   
?>