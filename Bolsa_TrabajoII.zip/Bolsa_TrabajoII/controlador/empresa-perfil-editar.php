<?php 
    require_once("modelo/empresa.php");
    $empresa = Array(
        "id_empresa"    => $_SESSION['id_empresa'],
        "r_social"      => test_input($_POST['r_social']),
        "rfc"           => test_input($_POST['rfc']),
        "email"         => test_input($_POST['email']),
        "domicilio"     => test_input($_POST['domicilio']),
        "telefono"      => test_input($_POST['telefono']),
        "giro"          => test_input($_POST['giro']),                
        "titular"       => test_input($_POST['titular']),
        "puesto_t"      => test_input($_POST['puesto_t']),
        "paginaweb"     => test_input($_POST['paginaweb'])                
    );
    if(!actualiza_empresa($empresa)){
        echo "ERROR";
    }
    $_SESSION['r_social'] = $empresa['r_social']; 
    $_SESSION['rfc'] = $empresa['rfc'];
    $_SESSION['giro'] = $empresa['giro'];            
    $_SESSION['titular'] = $empresa['titular'];
    $_SESSION['puesto_t'] = $empresa['puesto_t'];
    $_SESSION['email'] = $empresa['email'];
    $_SESSION['telefono'] = $empresa['telefono'];
    $_SESSION['domicilio'] = $empresa['domicilio'];
    $_SESSION['paginaweb'] = $empresa['paginaweb'];
    
    $_SESSION['msj'] = "Datos Actualizados";
    header("location: empresa.php");
    exit(0);    
?>