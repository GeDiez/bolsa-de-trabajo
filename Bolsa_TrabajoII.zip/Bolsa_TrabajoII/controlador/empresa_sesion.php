<?php    
require_once("modelo/empresa.php");
if($empresa = buscar_x_rfc($_POST['rfc'])){
    if($empresa['password'] == $_POST['clave']){
        $_SESSION['id_empresa'] = $empresa['id_empresa'];
        $_SESSION['r_social'] = $empresa['r_social']; 
        $_SESSION['rfc'] = $empresa['rfc'];
        $_SESSION['giro'] = $empresa['giro'];            
        $_SESSION['titular'] = $empresa['titular'];
        $_SESSION['puesto_t'] = $empresa['puesto_t'];
        $_SESSION['email'] = $empresa['email'];
        $_SESSION['telefono'] = $empresa['telefono'];
        $_SESSION['domicilio'] = $empresa['domicilio'];
        $_SESSION['paginaweb'] = $empresa['paginaweb'];
        $_SESSION['logo'] = $empresa['logo'];
        header("location: empresa.php");
    }
    else {
        $_SESSION['msj']="Contraseña incorrecta";        
    }
}
else {
    $_SESSION['msj']="RFC no ha sido registrado";    
}
exit(0);
?>