<?php 
require_once 'lib/herramientas.php';
if ($_GET['usuario'] == 1) {
    require_once 'modelo/egresado.php';
    $egresado = buscar_x_email($_POST['usuario']);
    if ($egresado) {
        $asunto = "Reestablecer clave de acceso Bolsa de Trabajo ITO";
        $cabecera = "From: <vin_oaxaca@tecnm.mx>";
        $mensaje = "Recuerda tu clave de acceso, para evitar ser dado de baja de la aplicacion".$egresado['clave'];
        envio_correo($egresado['email'], $asunto, $mensaje, $cabecera);
        $_SESSION['msj'] = "Se ha enviado tu clave de acceso a tu correo";
        header("location: index.php");
        exit(0);
    }
    else {
        $_SESSION['msj'] = "El correo ingresado no se encontro en la base de datos";
        header("location: index.php");
        exit(0);
    }
}
if ($_GET['usuario'] == 2) {
    require_once 'modelo/empresa.php';
    $empresa = buscar_x_rfc($_POST['usuario']);
    if ($empresa) {
        $asunto = "Reestablecer clave de acceso Bolsa de Trabajo ITO";
        $cabecera = "From: <vin_oaxaca@tecnm.mx>";
        $mensaje = "Recuerda tu clave de acceso".$empresa['clave'];
        envio_correo($empresa['email'], $asunto, $mensaje, $cabecera); 
        $_SESSION['msj'] = "Se ha enviado tu clave de acceso a tu correo";
        header("location: index.php");
        exit(0);
    }
    else {
        $_SESSION['msj'] = "El RFC ingresado no se encontro en la base de datos";
        header("location: index.php");
        exit(0);
    }
}
?>