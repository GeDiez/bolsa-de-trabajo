<?php 
    require_once("modelo/egresado.php");
    session_start();
    
    $email = test_input($_POST['email']);
    $captcha = test_input($_POST['captcha']);
    
    /*if (!verificar_captcha($captcha)) {
        $_SESSION['msj'] = "El Captcha no coincide";
        exit(0);
    }*/
    
    if(buscar_x_email($email)){
            $_SESSION['msj'] = "Este correo ya se registro";
        }
        else {
            $egresado = Array(
                "nombre" => test_input($_POST['nombre']),
                "carrera" => test_input($_POST['carrera']),
                "email" => test_input($_POST['email']),
                "domicilio" => test_input($_POST['domicilio']),
                "telefono" => test_input($_POST['telefono']),
                "trabajo" => test_input($_POST['trabajo']),                
                "titulado" => ((test_input($_POST['titulado']) == si) ? 1 : 0),
                "generacion" => test_input($_POST['generacion']),
                "clave" => (rand(1000, 9999))
            );
            $asunto = "Envio de Nip Acceso Al Sistemas Bolsa de Trabajo";
            $cabecera = "From: <vin_oaxaca@tecnm.mx>";
            $mensaje = "Regresa a la pagina principal y logeate con tu usuario y contraseña: ".$egresado['clave'];
            envio_correo($_POST['email'], $asunto, $mensaje, $cabecera);
            crear_egresado($egresado);
            $_SESSION['msj'] = "Revisa tu correo, y accede con tus datos";
            header("location: index.php");
            exit(0);
        }
?>