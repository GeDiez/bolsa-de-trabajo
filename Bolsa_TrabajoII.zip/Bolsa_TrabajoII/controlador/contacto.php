<?php 
    include_once("lib/herramientas.php");
    
    $asunto   = "Contacto desde plataforma Bolsa de Trabajo: ".$_POST['asunto'];
    $cabecera = "From: ".$_SESSION['email'];
    $mensaje  = $_POST['mensaje'];
    envio_correo("vin_oaxaca@tecnm.mx", $asunto, $mensaje, $cabecera);
    
    $_SESSION['msj'] = "El mensaje fue enviado";
                
?>