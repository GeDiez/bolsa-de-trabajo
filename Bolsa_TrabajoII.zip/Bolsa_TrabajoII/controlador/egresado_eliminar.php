<?php 
    include_once("modelo/egresado.php");
    
    eliminar_egresado($_SESSION['id_egresado']);
    
    $_SESSION['msj'] = "Tu cuenta ha sido Eliminada Satisfactoriamente, Gracias por utilizar nuestro servicio";
    header("location: index.php?query=cerrar_sesion");
    exit(0);
?>