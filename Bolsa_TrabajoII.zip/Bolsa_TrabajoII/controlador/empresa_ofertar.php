<?php 
    require_once("modelo/empresa.php");
    require_once("modelo/oferta.php");
    require_once("lib/herramientas.php");
    
    $oferta = array(
        "id_empresa" => $_SESSION['id_empresa'],
        "solicita"   => test_input($_POST['solicita']),
        "n_vacantes" => test_input($_POST['n_vacantes']),
        "puesto"     => test_input($_POST['puesto']),
        "requisitos" => test_input($_POST['requisitos'])        
    );
    
    crear_oferta($oferta);
    
    $_SESSION['msj'] = "La oferta ya esta disponible";

?>