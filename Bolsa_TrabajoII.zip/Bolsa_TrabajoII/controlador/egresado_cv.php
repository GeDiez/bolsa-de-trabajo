|<?php
    $_SESSION['msj'] = "";
	if ($_FILES['archivo'][size]>1000000){
			$_SESSION['msj'] = "El archivo es mayor que 1MB<BR>";
		}
	else{
		if (!($_FILES['archivo'][type] == "application/pdf")){
				$_SESSION['msj'] =" Formato aceptable PDF. Tu archivo es de tipo: ".$_FILES['archivo'][type];	
			}
		else{
			$nombre_archivo = "cv-".$_SESSION['id_egresado'].".pdf";
			$path="datosApp/CV/".$nombre_archivo;
			$existe_archivo = file_exists($path);
			if ($existe_archivo) {
                unlink($path);
				$_SESSION['msj'] = "Se ha actualizado tu CurriculumVitae.<br>";
			}
			if(move_uploaded_file ($_FILES['archivo'][tmp_name], $path)){
				$_SESSION['msj'].= "CV subido satisfactoriamente";
				}
			else{ 
				$_SESSION['msj'].= "Hubo un error al intentar subir el CV, intentalo mas tarde.";
				}
			}
		}
?>