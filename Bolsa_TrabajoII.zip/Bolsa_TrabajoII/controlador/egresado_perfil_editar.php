<?php 
    require_once("modelo/egresado.php");
        $egresado = Array(
            "id_egresado" => $_SESSION['id_egresado'],
            "nombre"      => test_input($_POST['nombre']),
            "carrera"     => test_input($_POST['carrera']),
            "email"       => test_input($_POST['email']),
            "domicilio"   => test_input($_POST['domicilio']),
            "telefono"    => test_input($_POST['telefono']),
            "trabajo"     => test_input($_POST['trabajo']),                
            "titulado"    => ((test_input($_POST['titulado']) == si) ? 1 : 0),
            "generacion"  => test_input($_POST['generacion'])
        );
        if(!actualiza_egresado($egresado)){
            echo "ERROR";
        }
        $_SESSION['nombre'] = $egresado['nombre']; 
        $_SESSION['carrera'] = $egresado['carrera'];
        $_SESSION['domicilio'] = $egresado['domicilio'];            
        $_SESSION['generacion'] = $egresado['generacion'];
        $_SESSION['telefono'] = $egresado['telefono'];
        $_SESSION['email'] = $egresado['email'];
        $_SESSION['domicilio'] = $egresado['domicilio'];
        $_SESSION['titulado'] = ($egresado['titulado'] == 1) ? si : no ;
        
        $_SESSION['msj'] = "Datos Actualizados";
        header("location: egresado.php");
        exit(0);   
?>