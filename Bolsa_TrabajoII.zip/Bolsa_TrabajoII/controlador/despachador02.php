<?php
    switch ($_GET['query']) {
        case 'perfil-editar':
            if ($_POST['rfc']) {
                require_once("controlador/empresa-perfil-editar.php");                
            }
            break;
            
        case 'ofertar':
            if($_POST['solicita']){
                require_once("controlador/empresa_ofertar.php");
            }
            break;
            
        case 'lofertas':
            require_once("controlador/empresa_lofertas.php");
            break;
            
        case 'lsolicitantes':
            require_once("controlador/empresa_lsolicitantes.php");
            break;
            
        case 'contacto':
            if ($_POST['mensaje']) {
                require_once("controlador/contacto.php");                
            }
            break;
            
        case 'eliminar':
            if ($_GET['confirmar'] === "si") {
                require_once("controlador/empresa_eliminar.php");                
            }
            break;
        
        default:
            break;
    }
    require_once("plantillas/layout_empresa.php");
?>