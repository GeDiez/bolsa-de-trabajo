<?php 
    include_once("modelo/solicitud.php");
    session_start();
    
    if ($_GET['id_solicitud']) {
        if(!eliminar_solicitud($_GET['id_solicitud'])){
            $_SESSION['Hubo un Error al Eliminar la solicitud'];
        }
    }
    
    $lista_solicitantes = ver_solicitudes_por_empresa($_SESSION['id_empresa']);
    
    if (!$lista_solicitantes) {
        $_SESSION['msj'] = "Aun no han solicitado tus Vacantes";
    }
?>