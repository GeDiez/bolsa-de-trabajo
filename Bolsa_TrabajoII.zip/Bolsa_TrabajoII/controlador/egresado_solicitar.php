<?php 
    include_once("modelo/solicitud.php");
    
    $solicitud = array(
        "id_oferta" => $_GET['id_oferta'],
        "id_egresado" => $_SESSION['id_egresado']
    );
    crear_solicitud($solicitud);
    
    $_SESSION['msj']="Tu solicitud ha sido exitosa!";
    header("location: egresado.php?query_ofertas.php");
    exit(0);
?>