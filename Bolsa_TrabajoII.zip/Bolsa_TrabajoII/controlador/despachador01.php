<?php
    switch ($_GET['query']) {            
        case 'perfil-editar':
            if ($_POST['nombre']) {
                require_once("controlador/egresado_perfil_editar.php");                            
            }
            break;
            
        case 'ofertas':
            require_once("controlador/egresado_ofertas.php");
            break;
            
        case 'solicitar':
            if($_GET['id_oferta']){
                require_once("controlador/egresado_solicitar.php");
            }
            break;
            
        case 'guarda-cv':
            require_once("controlador/egresado_cv.php");
            break;
        
        case 'contacto':
            if ($_POST['mensaje']) {
                require_once("controlador/contacto.php");                
            }
            break;
        case 'eliminar':
            if ($_GET['confirmar']==="si") {
                require_once("controlador/egresado_eliminar.php");                
            }
            break;
            
        default:
            break;
    }
    require_once("plantillas/layout_egresado.php");
?>