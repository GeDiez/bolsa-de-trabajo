<?php 
    require_once("modelo/empresa.php");
    session_start();
    
    $rfc = test_input($_POST['rfc']);
    $captcha = test_input($_POST['captcha']);
    
    /*if (!verificar_captcha($captcha)) {
        $_SESSION['msj'] = "El Captcha no coincide";
        exit(0);
    }*/
    
    $logo = "logo-".$rfc.".".end(explode(".", $_FILES['logo']['name']));

    if($_FILES['logo']['size'] >= 1000000){
      $_SESSION['msj'] = "La imagen debe pesar menos de 1MB";
    }
    else{
        if(!($_FILES['logo']['type']=="image/jpeg" or $_FILES['logo']['type']=="image/png" or $_FILES['logo']['type']=="image/jpg")){
        $_SESSION['msj'] = "La imagen debe ser formato JPEG o PNG";
        }
        else{
        if(buscar_x_rfc($rfc)){
                $_SESSION['msj'] = "Este RFC ya se registro";
            }
            else {
                $empresa = Array(
                    "r_social" => test_input($_POST['r_social']),
                    "rfc" => test_input($_POST['rfc']),
                    "email" => test_input($_POST['email']),
                    "domicilio" => test_input($_POST['domicilio']),
                    "telefono" => test_input($_POST['telefono']),
                    "giro" => test_input($_POST['giro']),                
                    "titular" => test_input($_POST['titular']),
                    "puesto_t" => test_input($_POST['puesto_t']),
                    "paginaweb" => test_input($_POST['paginaweb']),                
                    "logo" => $logo,
                    "clave" => (rand(1000, 9999))
                );
                move_uploaded_file(($_FILES['logo']['tmp_name']), "datosApp/logotipos/".$logo);
                $asunto = "Envio de Nip Acceso Al Sistemas Bolsa de Trabajo";
                $cabecera = "From: <vin_oaxaca@tecnm.mx>";
                $mensaje = "Regresa a la pagina principal y logeate con tu usuario y contraseña: ".$empresa['clave'];
                envio_correo($_POST['email'], $asunto, $mensaje, $cabecera);
                crear_empresa($empresa);
                $_SESSION['msj'] = "Revisa tu correo, y accede con tus datos";
                header("location: index.php");
                exit(0);
            }
        }
    }
?>