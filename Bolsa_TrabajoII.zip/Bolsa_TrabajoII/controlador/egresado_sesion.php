<?php    
    require_once("modelo/egresado.php");
    if($egresado = buscar_x_email($_POST['email'])){
        if($egresado['password'] == $_POST['clave']){
            $_SESSION['id_egresado'] = $egresado['id_egresado'];             
            $_SESSION['nombre'] = $egresado['nombre']; 
            $_SESSION['carrera'] = $egresado['carrera'];
            $_SESSION['domicilio'] = $egresado['domicilio'];            
            $_SESSION['generacion'] = $egresado['generacion'];
            $_SESSION['telefono'] = $egresado['telefono'];
            $_SESSION['email'] = $egresado['email'];
            $_SESSION['domicilio'] = $egresado['domicilio'];
            $_SESSION['titulado'] = ($egresado['titulado'] == 1) ? si : no ;
            header("location: egresado.php");
        }
        else {
            $_SESSION['msj'] = "La clave de acceso es incorrecta ";                
        }
    }
    else{
        $_SESSION['msj'] = "El Correo de acceso es incorrecto";
    }
    
?>