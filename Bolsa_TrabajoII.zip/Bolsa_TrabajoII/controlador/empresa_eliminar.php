<?php 
    include_once("modelo/empresa.php");
    
    eliminar_empresa($_SESSION['id_empresa']);
    
    $_SESSION['msj'] = "Tu cuenta ha sido Eliminada Satisfactoriamente, Gracias por utilizar nuestro servicio";
    header("location: index.php?query=cerrar_sesion");
    exit(0);
?>