<?php
switch ($_GET['query']) {
        case 'reg_egresado':
            if ($_POST['email']) {
                require_once("controlador/egresado_registro.php");                
            }
            break;
        
        case 'sesion_egresado': 
            if ($_POST['email']) {
                require_once("controlador/egresado_sesion.php");
            }
        case 'reg_empresa':
            if ($_POST['rfc']) {
                require_once("controlador/empresa_registro.php");            
            }
            break;
        
        case 'empresa_sesion': 
            if ($_POST['rfc']) {
                require_once("controlador/empresa_sesion.php");
            }
            break;
        
        case 'reestablecer_clave':
            if($_GET['usuario']){
                require_once("controlador/reestablecer_clave.php");   
            }
            break;
            
        case 'cerrar_sesion':
            session_start();
            session_destroy();
            header("location: index.php");
            exit(0);
            break;
            
        default:
            break;
    }
?>