<?php 
    require_once("modelo/empresa.php");
    require_once("modelo/oferta.php");
    
    $carrera = test_input($_GET['carrera']);
    $empresa = test_input($_GET['empresa']);

    $empresas = listar_empresas();
    
    $ofertas = oferta_x_carrera_empresa($carrera, $empresa);
    if (!$ofertas) {
        $_SESSION['msj'] = "Seleccione alguna carrera o alguna empresa en especial";
    }
?>