<?php 
    include_once("modelo/oferta.php");    
    if ($_GET['id_oferta']) {
        if(!eliminar_oferta($_GET['id_oferta'])){
            $_SESSION['Hubo un Error al Eliminar'];
        }
    }  
    if (!$lista_de_ofertas = oferta_x_carrera_empresa("Todo", $_SESSION['r_social'])) {
        $_SESSION['msj'] = "No Existe ninguna Oferta disponible, Crea una en Ofertas -> Ofertar";
    }  
    
?>