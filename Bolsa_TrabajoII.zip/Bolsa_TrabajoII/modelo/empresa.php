<?php
require_once("lib/herramientas.php");
$conexion = conexion_bd();
    //Definimos la funciones sobre el objeto empresa
    function crear_empresa($empresa){
        global $conexion;
        $sql = "INSERT INTO empresa ";
        $sql.= "SET r_social='".$empresa['r_social']."', rfc='".$empresa['rfc']."',";
        $sql.= "email='".$empresa['email']."', giro='".$empresa['giro']."',";
        $sql.= "titular='".$empresa['titular']."', puesto_t='".$empresa['puesto_t']."',"; 
        $sql.= "paginaweb='".$empresa['paginaweb']."', logo='".$empresa['logo']."',";
        $sql.= "domicilio='".$empresa['domicilio']."', telefono='".$empresa['telefono']."', password='".$empresa['clave']."'";
        return consulta($sql, $conexion);
    }
    
    //Definimos una funcion que acutualice al empresa 
    function actualiza_empresa($empresa){
        global $conexion;
        $sql = "UPDATE empresa ";
        $sql.= "SET r_social='".$empresa['r_social']. "', rfc='".     $empresa['rfc'].     "',";
        $sql.= "email='"       .$empresa['email'].    "', giro='".    $empresa['giro'].    "',";
        $sql.= "titular='"     .$empresa['titular'].  "', puesto_t='".$empresa['puesto_t']."',"; 
        $sql.= "paginaweb='"   .$empresa['paginaweb']."', ";
        $sql.= "domicilio='"   .$empresa['domicilio']."', telefono='".$empresa['telefono']."' ";
        $sql.= "WHERE id_empresa = '".$empresa['id_empresa']."'";
        return consulta($sql, $conexion);
    }
    
    //Definimos una funcion que devuelve un empresa especifico
    function buscar_x_rfc($rfc){
        global $conexion;
        $sql = "select * from empresa ";
        $sql.= "where rfc = '$rfc'";
        $consulta = mysqli_fetch_array(consulta($sql, $conexion));
        return $consulta;
    }
    
    //Definimos una funcion que devuelve un empresa especifico    
    function listar_empresas(){
        global $conexion;
        $sql = "select r_social from empresa";
        $consulta = consulta($sql, $conexion);
        return $consulta;
    }
    
    //Definimos una funcion que elimine un empresa 
    function eliminar_empresa($id_empresa){
        global $conexion;
        $sql = "delete from empresa ";
        $sql.= "where id_empresa = '$id_empresa'";
        return consulta($sql, $conexion);
    }
?>