<?php
require_once("lib/herramientas.php");
$conexion = conexion_bd();
    //Definimos la funciones sobre el objeto solicitud
    function crear_solicitud($solicitud){
        global $conexion;
        $sql = "INSERT INTO solicitud ";
        $sql.= "SET id_oferta = '".$solicitud['id_oferta']."', id_egresado = '".$solicitud['id_egresado']."'";
        return consulta($sql, $conexion);
    }
    
    //Definimos una funcion que devuelve un solicitud especifico
    function ver_solicitudes_por_empresa($id_empresa){
        global $conexion;
        $sql = "select * from solicitud inner join egresado using(id_egresado) inner join oferta using(id_oferta) ";
        $sql.= "where id_empresa = '".$id_empresa."'";
        $consulta =  consulta($sql, $conexion);
        return $consulta;
        
    }
    
    //Definimos una funcion que elimine un solicitud 
    function eliminar_solicitud($id_solicitud){
        global $conexion;
        $sql = "delete from solicitud ";
        $sql.= "where id_solicitud = '$id_solicitud'";
        return consulta($sql, $conexion);
    }
?>