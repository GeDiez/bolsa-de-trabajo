<?php
require_once("lib/herramientas.php");
$conexion = conexion_bd();
    //Definimos la funciones sobre el objeto Egresado
    function crear_egresado($egresado){
        global $conexion;
        $sql = "INSERT INTO egresado ";
        $sql.= "SET nombre='".$egresado['nombre']."', carrera='".$egresado['carrera']."', ";
        $sql.= "email='".$egresado['email']."', generacion='".$egresado['generacion']."', ";
        $sql.= "titulado='".$egresado['titulado']."', trabajo='".$egresado['trabajo']."', "; 
        $sql.= "domicilio='".$egresado['domicilio']."', telefono='".$egresado['telefono']. "', password='".$egresado['clave']."'";
        return consulta($sql, $conexion);
    }
    //Definimos una funcion que acutualice al egresado 
    function actualiza_egresado($egresado){
        global $conexion;
        $sql = "UPDATE egresado ";
        $sql.= "SET nombre='".$egresado['nombre'].   "', carrera='"    .$egresado['carrera'].   "', ";
        $sql.= "email='"     .$egresado['email'].    "', generacion='" .$egresado['generacion']."', ";
        $sql.= "titulado='"  .$egresado['titulado']. "', trabajo='"    .$egresado['trabajo'].   "', "; 
        $sql.= "domicilio='" .$egresado['domicilio']."', telefono='"   .$egresado['telefono'].  "'  ";
        $sql.= "where id_egresado = '".$egresado['id_egresado']."'";
        return consulta($sql, $conexion);
    }
    
    //Definimos una funcion que devuelve un egresado especifico
    function buscar_x_email($email){
        global $conexion;
        $sql = "select * from egresado ";
        $sql.= "where email = '$email'";
        $consulta = mysqli_fetch_array(consulta($sql, $conexion));
        if($consulta){
            return $consulta;
        }
    }
    
    function buscar_x_id($id_egresado){
        global $conexion;
        $sql = "select * from egresado ";
        $sql.= "where id_egresado = '$id_egresado'";
        $consulta = mysqli_fetch_array(consulta($sql, $conexion));
        return $consulta;
    }
    
    //Definimos una funcion que elimine un egresado 
    function eliminar_egresado($id_egresado){
        global $conexion;
        $sql = "delete from egresado ";
        $sql.= "where id_egresado = '$id_egresado'";
        return consulta($sql, $conexion);
    }
?>