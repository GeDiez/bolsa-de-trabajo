<?php
require_once("lib/herramientas.php");
$conexion = conexion_bd();
    //Definimos la funciones sobre el objeto oferta
    function crear_oferta($oferta){
        global $conexion;
        $sql = "INSERT INTO oferta ";
        $sql.= "SET id_empresa='".$oferta['id_empresa']."', solicita='".$oferta['solicita']."',";
        $sql.= "puesto='".$oferta['puesto']."', n_vacantes='".$oferta['n_vacantes']."',";
        $sql.= "requisitos='".$oferta['requisitos']."'"; 
        return consulta($sql, $conexion);
    }
    //Definimos una funcion que acutualice al oferta 
    function actualiza_oferta($oferta){
        $sql = "select * from oferta ";
        $sql.= "where id_oferta = '$oferta[id_oferta]'";
        $consulta = consulta($sql, $conexion);
        if($consulta['id_oferta']){
            $sql.= "UPDATE oferta";
            $sql.= "SET nombre='$nombre', carrera='$carrera', email='$email', generacion='$generacion', titulado='$titulado', trabajo='$trabajo',domicilio='$domicilio', telefono='$telefono'"; 
            return consulta($sql, $conexion);
        }
        else{
            return false;
        }
    }
    
    //Definimos una funcion que devuelve un oferta especifico
    
    function oferta_x_carrera_empresa($carrera, $empresa){
        global $conexion;
        $sql = "select * from oferta inner join empresa using(id_empresa) "; 
        if (!($carrera=="Todo") or !($empresa=="Todo")){
            $sql.= "where ";
            if (!($carrera == "Todo")) {
                $sql.="solicita='".$carrera."' ";
            }
            if (!($carrera=="Todo") and !($empresa=="Todo")) {
                $sql.="and ";
            }
            if (!($empresa == "Todo")) {
                $sql.="r_social='".$empresa."' ";
            }
        }                      
        $consulta = consulta($sql, $conexion);
        return $consulta;
    }
    
    //Definimos una funcion que elimine un oferta 
    function eliminar_oferta($id_oferta){
        global $conexion;
        $sql = "delete from oferta ";
        $sql.= "where id_oferta = '$id_oferta'";
        $consulta= consulta($sql, $conexion);
        return $consulta;
    }
?>